<?php
$servidor = 'localhost'; //Nome do banco de dados
$bd_login = 'root'; //Login do banco de dados
$bd_senha = ''; //Senha do banco de dados
$bd_banco = 'slppi4';//Tabela do banco de dados
//$bd_tabela = 'cliente';

//id10968324_slppi4
//nuncaesquecerasenha
//id10968324_mydb

$conn = mysqli_connect ($servidor, $bd_login, $bd_senha, $bd_banco);
?>