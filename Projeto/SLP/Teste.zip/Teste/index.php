<!DOCTYPE html>
<html>
<head>
	<title>Teste</title>
</head>
<body>

<form action="teste.php" method="POST">
	<input type="submit" name="gera" id="gera" value="Clique aqui para gerar o seu cupom">
</form>

</body>
</html>

